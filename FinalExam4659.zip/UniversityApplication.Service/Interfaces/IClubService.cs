﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UniversityApplication.Data.Entities;
using UniversityApplication.Models.DTOs;

namespace UniversityApplication.Service.Interfaces
{
    public interface IClubService
    {
        Task<IEnumerable<Club>> GetClubs();
        Task<Club> GetClubById(int id);
        ClubDTO AddClub(ClubDTO player);
        ClubDTO UpdateClub(ClubDTO player);
        Task<bool> DeleteClub(int id);

    }
}
