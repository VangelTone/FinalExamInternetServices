﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UniversityApplication.Data;
using UniversityApplication.Data.Entities;
using UniversityApplication.Models.DTOs;
using UniversityApplication.Service.Interfaces;
using AutoMapper;


namespace UniversityApplication.Service.Services
{
    public class ClubService : IClubService
    {
        private readonly UniversityDataContext _dataContext;
        private readonly IMapper _mapper;


        public ClubService(UniversityDataContext dataContext, IMapper mapper)
        {
            _dataContext = dataContext;
            _mapper = mapper;
        }

        public async Task<Club> GetClubById(int id)
        {
            return await _dataContext.Clubs.FirstOrDefaultAsync(x => x.Id == id);
        }

        public async Task<IEnumerable<Club>> GetClubs()
        {
            return await _dataContext.Clubs.ToListAsync();
        }

        public ClubDTO AddClub(ClubDTO club)
        {
            Club newClub = _mapper.Map<Club>(club);

            if (_dataContext.Clubs.FirstOrDefault(s => s.Id == club.Id) == null)
            {
                _dataContext.Clubs.Add(newClub);
                _dataContext.SaveChanges();
            }
            return _mapper.Map<ClubDTO>(newClub);
        }

        public ClubDTO UpdateClub(ClubDTO club)
        {
            Club newClub = _mapper.Map<Club>(club);
            Club oldClub = _dataContext.Clubs.FirstOrDefault(s => s.Id == newClub.Id);

            if (oldClub != null)
            {
                _dataContext.Entry(oldClub).CurrentValues.SetValues(newClub);
                _dataContext.SaveChanges();
            }
            return _mapper.Map<ClubDTO>(newClub);
        }
        public async Task<bool> DeleteClub(int id)
        {
            var clubEntity = await _dataContext.Clubs.FindAsync(id);
            _dataContext.Clubs.Remove(clubEntity);
            return await SaveAsync() > 0;
        }

        public async Task<int> SaveAsync()
        {
            return await _dataContext.SaveChangesAsync();
        }
    }
}
