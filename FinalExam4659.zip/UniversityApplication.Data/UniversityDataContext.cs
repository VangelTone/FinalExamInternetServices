﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.SqlServer.Infrastructure.Internal;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UniversityApplication.Data.Entities;

namespace UniversityApplication.Data
{
    public class UniversityDataContext : DbContext
    {
        private readonly string _connStr;

        public UniversityDataContext(DbContextOptions<UniversityDataContext> options)
        {
        #pragma warning disable EF1001 // Internal EF Core API usage.
            SqlServerOptionsExtension sqlServerOptionsExtension = options.FindExtension<SqlServerOptionsExtension>();
        #pragma warning restore EF1001 // Internal EF Core API usage.

            if (sqlServerOptionsExtension != null)
            {
                _connStr = sqlServerOptionsExtension.ConnectionString;
            }
        }

        public virtual DbSet<Player> Players { get; set; }
        public virtual DbSet<Club> Clubs { get; set; }


        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(_connStr, providerOptions => providerOptions.CommandTimeout(60));
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Player>(entiry =>
            {
                entiry.HasKey(e => e.Id);

                entiry.Property(e => e.FirstName)
                .HasMaxLength(200)
                .IsUnicode(true)
                .IsRequired(true);

                entiry.Property(e => e.LastName)
                .HasMaxLength(400)
                .IsUnicode(true)
                .IsRequired(true);

                entiry.Property(e => e.DOB)
                .HasColumnName("DateOfBirth")
                .HasColumnType("datetime")
                .IsRequired(false);

                entiry.Property(e => e.SigningDate)
                .HasColumnName("SigningtDate")
                .HasColumnType("datetime")
                .IsRequired(true);

                entiry.Property(e => e.Rank)
               .IsUnicode(true)
               .IsRequired(true);

                entiry.Property(e => e.TotalGoals)
               .HasColumnName("TotalGoals")
               .HasColumnType("int")
               .IsRequired(true);

                entiry.Property(e => e.ClubId)
               .HasColumnName("ClubId")
               .HasColumnType("int")
               .IsRequired(true);

                entiry.HasOne(e => e.Club);
            });

            modelBuilder.Entity<Player>()
                .HasOne(s => s.Club)
                .WithMany(a => a.Players);

            modelBuilder.Entity<Club>(entity =>
            {
                entity.HasKey(a => a.Id);

                entity.Property(a => a.Owner)
                    .HasMaxLength(200)
                    .IsUnicode(true)
                    .IsRequired(true);

                entity.Property(a => a.City)
                    .HasMaxLength(200)
                    .IsUnicode(true)
                    .IsRequired(true);

                entity.Property(a => a.Country)
                    .HasMaxLength(200)
                    .IsUnicode(true)
                    .IsRequired(true);
            });

            modelBuilder.Entity<Club>()
                .HasMany(s => s.Players)
                .WithOne(a => a.Club);

            modelBuilder.Entity<Club>().HasData(
                new Club { Id = 1, City = "New York", Owner = "Josh", Country = "USA" },
                new Club { Id = 2, City = "Sydney", Owner = "Jim", Country = "Australia" },
                new Club { Id = 3, City = "Rome", Owner = "Jake", Country = "Italy" },
                new Club { Id = 4, City = "Los Angeles", Owner = "Jack", Country = "USA" },
                new Club { Id = 5, City = "Tokyo", Owner = "John", Country = "Japan" }
                );

            modelBuilder.Entity<Player>().HasData(
                new Player
                {
                    Id = 1,
                    FirstName = "Kessidy",
                    LastName = "Truman",
                    TotalGoals = 1,
                    ClubId = 2,
                    Rank = "Beginner",
                    SigningDate = DateTime.Today.AddYears(-3)
                },
                 new Player
                 {
                     Id = 2,
                     FirstName = "Christobel",
                     LastName = "Bezuidenhout",
                     TotalGoals=3,
                     ClubId = 5,
                     Rank = "Intermediate",
                     SigningDate = DateTime.Today.AddYears(-4)
                 },
               new Player
               {
                   Id = 3,
                   FirstName = "Kristel",
                   LastName = "Madison",
                   TotalGoals = 2,
                   ClubId = 1,
                   Rank = "Expert",
                   SigningDate = DateTime.Today.AddYears(-2)
               },
               new Player
               {
                   Id = 4,
                   FirstName = "Lyndsey",
                   LastName = "Albers",
                   TotalGoals = 4,
                   ClubId = 3,
                   Rank = "Beginner",
                   SigningDate = DateTime.Today.AddYears(-1)
               },
               new Player
               {
                   Id = 5,
                   FirstName = "Alishia",
                   LastName = "Gabriels",
                   TotalGoals = 1,
                   ClubId = 4,
                   Rank = "Beginner",
                   SigningDate = DateTime.Today.AddYears(-3)
               }
                );

        }
    }
}
