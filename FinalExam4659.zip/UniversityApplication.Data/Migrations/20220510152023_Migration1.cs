﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace UniversityApplication.Data.Migrations
{
    public partial class Migration1 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Clubs",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Owner = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: false),
                    City = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: false),
                    Country = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Clubs", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Players",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    FirstName = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: false),
                    LastName = table.Column<string>(type: "nvarchar(400)", maxLength: 400, nullable: false),
                    DateOfBirth = table.Column<DateTime>(type: "datetime", nullable: true),
                    SigningtDate = table.Column<DateTime>(type: "datetime", nullable: false),
                    Rank = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    TotalGoals = table.Column<int>(type: "int", nullable: false),
                    ClubId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Players", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Players_Clubs_ClubId",
                        column: x => x.ClubId,
                        principalTable: "Clubs",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                table: "Clubs",
                columns: new[] { "Id", "City", "Country", "Owner" },
                values: new object[,]
                {
                    { 1, "New York", "USA", "Josh" },
                    { 2, "Sydney", "Australia", "Jim" },
                    { 3, "Rome", "Italy", "Jake" },
                    { 4, "Los Angeles", "USA", "Jack" },
                    { 5, "Tokyo", "Japan", "John" }
                });

            migrationBuilder.InsertData(
                table: "Players",
                columns: new[] { "Id", "ClubId", "DateOfBirth", "FirstName", "LastName", "Rank", "SigningtDate", "TotalGoals" },
                values: new object[,]
                {
                    { 3, 1, null, "Kristel", "Madison", "Expert", new DateTime(2020, 5, 10, 0, 0, 0, 0, DateTimeKind.Local), 2 },
                    { 1, 2, null, "Kessidy", "Truman", "Beginner", new DateTime(2019, 5, 10, 0, 0, 0, 0, DateTimeKind.Local), 1 },
                    { 4, 3, null, "Lyndsey", "Albers", "Beginner", new DateTime(2021, 5, 10, 0, 0, 0, 0, DateTimeKind.Local), 4 },
                    { 5, 4, null, "Alishia", "Gabriels", "Beginner", new DateTime(2019, 5, 10, 0, 0, 0, 0, DateTimeKind.Local), 1 },
                    { 2, 5, null, "Christobel", "Bezuidenhout", "Intermediate", new DateTime(2018, 5, 10, 0, 0, 0, 0, DateTimeKind.Local), 3 }
                });

            migrationBuilder.CreateIndex(
                name: "IX_Players_ClubId",
                table: "Players",
                column: "ClubId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Players");

            migrationBuilder.DropTable(
                name: "Clubs");
        }
    }
}
