﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace UniversityApplication.WebApi.Infrastructure
{
    public class ConnectionSrings
    {
        public string DefaultConnection { get; set; }
    }
}
