﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UniversityApplication.Data.Entities;
using UniversityApplication.Models.DTOs;
using UniversityApplication.Service.Interfaces;

namespace UniversityApplication.WebApi.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class PlayerController : ControllerBase
    {

        private readonly IPlayerService _playerService;

        public PlayerController(IPlayerService playerService)
        {
            _playerService = playerService;
        }

        [HttpGet]
        [Route("GetAllPlayers")]
        public IEnumerable<PlayerDTO> GetPlayers()
        {
            var player = _playerService.GetPlayers();

            return player;
        }

        [HttpGet]
        [Route("GetPlayerById")]
        public async Task<IActionResult> GetPlayerById(int id)
        {
            PlayerDTO player = await _playerService.GetPlayerById(id);

            if (player == null)
            {
                return NotFound("Player with that id does not exist!");
            }

            return Ok(player);
        }

        [HttpDelete("RemovePlayer/{id:int}")]
        public async Task<IActionResult> Delete([FromRoute] int id)
        {
            if (ModelState.IsValid)
            {
                return Ok(await _playerService.DeletePlayer(id));
            }
            return BadRequest();
        }

        [HttpPost("AddPlayer")]
        public IActionResult Post([FromBody] PlayerDTO player)
        {
            if (ModelState.IsValid)
            {
                var newPlayer = _playerService.AddPlayer(player);
                return Created($"Player with id {newPlayer.Id} is created", newPlayer.Id);
            }

            return UnprocessableEntity(ModelState);
        }

        [HttpPut("UpdatePlayer/{id:int}")]
        public IActionResult Put([FromRoute] int id, [FromBody] PlayerDTO player)
        {
            if (ModelState.IsValid)
            {
                player.Id = id;
                var result = _playerService.UpdatePlayer(player);

                return result != null
                    ? Ok(result)
                    : NoContent();
            }
            return BadRequest();
        }
    }
}
