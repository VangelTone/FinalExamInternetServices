﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UniversityApplication.Data.Entities;
using UniversityApplication.Models.DTOs;
using UniversityApplication.Service.Interfaces;

namespace UniversityApplication.WebApi.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class ClubController : ControllerBase
    {
        private readonly IClubService _clubService;
        public ClubController(IClubService clubService)
        {
            _clubService = clubService;
        }

        [HttpGet]
        [Route("GetAllClubs")]
        public async Task<IEnumerable<Club>> GetClubs()
        {
            var clubs = await _clubService.GetClubs();

            return clubs;
        }

        [HttpGet]
        [Route("GetClubById")]
        public async Task<IActionResult> GetClubById(int id)
        {
            Club club = await _clubService.GetClubById(id);

            if (club == null)
            {
                return NotFound("Club with that id does not exist!");
            }

            return Ok(club);
        }

        [HttpPost("AddClub")]
        public IActionResult Post([FromBody] ClubDTO club)
        {
            if (ModelState.IsValid)
            {
                var newClub = _clubService.AddClub(club);
                return Created($"Club with id {newClub.Id} is created", newClub.Id);
            }

            return UnprocessableEntity(ModelState);
        }

        [HttpPut("UpdateClub/{id:int}")]
        public IActionResult Put([FromRoute] int id, [FromBody] ClubDTO club)
        {
            if (ModelState.IsValid)
            {
                club.Id = id;
                var result = _clubService.UpdateClub(club);

                return result != null
                    ? Ok(result)
                    : NoContent();
            }
            return BadRequest();
        }


        [HttpDelete("RemoveClub/{id:int}")]
        public async Task<IActionResult> Delete([FromRoute] int id)
        {
            if (ModelState.IsValid)
            {
                return Ok(await _clubService.DeleteClub(id));
            }
            return BadRequest();
        }
    }
}
