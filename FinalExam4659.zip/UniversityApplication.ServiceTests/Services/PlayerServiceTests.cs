﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using UniversityApplication.Service.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UniversityApplication.Data.Entities;

namespace UniversityApplication.Service.Services.Tests
{
    [TestClass()]
    public class PlayerServiceTests
    {
        [TestMethod()]
        public void GetPlayerByIdTest()
        {
            var player = new Player { Id = 1, FirstName = "Kessidy", LastName = "Truman", TotalGoals = 1, ClubId = 2,Rank = "Beginner", SigningDate = DateTime.Today.AddYears(-3) };
            var playerId = player.Id;
            var expectedId = 1;
            Assert.AreEqual(playerId, expectedId);
        }

        [TestMethod()]
        public void MatchCitiesByIdTest()
        {
            var player = new Player { Id = 1, FirstName = "Kessidy", LastName = "Truman", TotalGoals = 1, ClubId = 2, Rank = "Beginner", SigningDate = DateTime.Today.AddYears(-3) };
            var playerFirstName = player.FirstName;
            var expectedFirstName = "Kessidy";
            Assert.AreEqual(playerFirstName, expectedFirstName);
        }

        [TestMethod()]
        public void PlayerIsNotNullTest()
        {
            var player = new Player { Id = 1, FirstName = "Kessidy", LastName = "Truman", TotalGoals = 1, ClubId = 2, Rank = "Beginner", SigningDate = DateTime.Today.AddYears(-3) };
            Assert.IsNotNull(player);
        }
    }
}