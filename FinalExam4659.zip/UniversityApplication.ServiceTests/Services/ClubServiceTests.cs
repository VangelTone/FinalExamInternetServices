﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using UniversityApplication.Service.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UniversityApplication.Data.Entities;
using AutoMapper;
using UniversityApplication.Data;

namespace UniversityApplication.Service.Services.Tests
{
    [TestClass()]
    public class ClubServiceTests
    {

        [TestMethod()]
        public void GetClubByIdTest()
        {
            var club = new Club { Id = 1, City = "New York", Owner = "Josh", Country = "USA" };
            var clubId = club.Id;
            var expectedId = 1;
            Assert.AreEqual(clubId, expectedId);
        }

        [TestMethod()]
        public void MatchCitiesByIdTest()
        {
            var club = new Club { Id = 1, City = "New York", Owner = "Josh", Country = "USA" };
            var clubCity = club.City;
            var expectedCity = "New York";
            Assert.AreEqual(clubCity, expectedCity);
        }

        [TestMethod()]
        public void ClubIsNotNullTest()
        {
            var club = new Club { Id = 1, City = "New York", Owner = "Josh", Country = "USA" };
            Assert.IsNotNull(club);
        }
    }
}